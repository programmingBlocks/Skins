local sButton = Var'Button'
local cntrl = Var("Controller")
local t = Def.ActorFrame {
	HoldingOnCommand=function(self)
		MESSAGEMAN:Broadcast("ExplosionHoldingOn",{key=sButton,cntrl=cntrl})
		self:queuecommand("HoldingAction")
	end	,
	HoldingOffCommand=function(self)
		MESSAGEMAN:Broadcast("ExplosionHoldingOff",{key=sButton,cntrl=cntrl})
		self:stoptweening()
	end	,
	RollOnCommand=function(self)
		MESSAGEMAN:Broadcast("ExplosionHoldingOn",{key=sButton,cntrl=cntrl})
		self:queuecommand("HoldingAction")
	end	,
	RollOffCommand=function(self)
		MESSAGEMAN:Broadcast("ExplosionHoldingOff",{key=sButton,cntrl=cntrl})
		self:stoptweening()
	end	,
	HoldingActionCommand=function(self)
		self:sleep(0.12):queuecommand("HoldingAction")		
	end	,
	Def.ActorFrame {
		InitCommand=function(self)
			self:diffusealpha(0)
		end;
		W1Command=function(self)
			self:GetChild("Glow"):setstate(0)
			self:stoptweening():zoom(1.08):diffusealpha(2):decelerate(0.3):diffusealpha(0):zoom(1)
		end;
		W2Command=function(self)
			self:GetChild("Glow"):setstate(1)
			self:stoptweening():zoom(1.08):diffusealpha(2):decelerate(0.3):diffusealpha(0):zoom(1)
		end;
		W3Command=function(self)
			self:GetChild("Glow"):setstate(2)
			self:stoptweening():zoom(1.08):diffusealpha(2):decelerate(0.3):diffusealpha(0):zoom(1)
		end;
		HoldingActionCommand=function(self)
			self:stoptweening():zoom(1.08):diffusealpha(2):decelerate(0.3):diffusealpha(0):zoom(1)
		end;
		Def.Sprite {
			Texture=NOTESKIN:GetPath( '', '_glow base' );
		};
		Def.Sprite {
			Name="Glow";
			Texture=NOTESKIN:GetPath( '_down','glow' );
			Frames=Sprite.LinearFrames(3, 1),
			InitCommand=function(self)
				self:blend(1):pause(1):setstate(0)
			end;

		};
	};

}
return t;