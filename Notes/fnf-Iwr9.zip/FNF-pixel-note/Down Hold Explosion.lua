local t = Def.ActorFrame{
	Def.Sprite {
		Texture=NOTESKIN:GetPath( '_w1', 'glow' );
		Frames=Sprite.LinearFrames(2, 0.1);
		InitCommand=function(self)
			self:diffusealpha(0)
		end;
		W1Command=function(self)
			self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
		end;
		W2Command=function(self)
			self:diffusealpha(0)
		end;
		W3Command=function(self)
			self:diffusealpha(0)
		end;
		HoldingOnCommand=function(self)
			self:diffusealpha(1):setstate(0)
		end;
		HoldingOffCommand=function(self)
			self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
		end;
		RollOnCommand=function(self)
			self:diffusealpha(1):setstate(0)
		end;
		RollOffCommand=function(self)
			self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
		end;
	};
	Def.Sprite {
		Texture=NOTESKIN:GetPath( '_w2', 'glow' );
		Frames=Sprite.LinearFrames(2, 0.1);
		InitCommand=function(self)
			self:diffusealpha(0)
		end;
		W1Command=function(self)
			self:diffusealpha(0)
		end;
		W2Command=function(self)
			self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
		end;
		W3Command=function(self)
			self:diffusealpha(0)
		end;
	};
	Def.Sprite {
		Texture=NOTESKIN:GetPath( '../FNF-pixel/_up', 'glow' );
		Frames=Sprite.LinearFrames(2, 0.1);
		InitCommand=function(self)
			self:diffusealpha(0)
		end;
		W1Command=function(self)
			self:diffusealpha(0)
		end;
		W2Command=function(self)
			self:diffusealpha(0)
		end;
		W3Command=function(self)
			self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
		end;
	};
}
return t;