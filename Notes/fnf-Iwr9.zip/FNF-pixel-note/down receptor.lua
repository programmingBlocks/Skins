local t = Def.ActorFrame {
	Name="Receptor",
	Def.Sprite {
		Name="Base";
		Texture=NOTESKIN:GetPath( '', '../FNF-pixel/_Receptor' );
	};
	Def.Sprite {
		Name="Glow";
		Texture=NOTESKIN:GetPath( '_down', 'press' );
		InitCommand=function(self)
			self:diffusealpha(0)
		end;
		NoneCommand=function(self)
			self:diffusealpha(1)
		end;
		LiftCommand=function(self)
			self:diffusealpha(0)
		end;
	};
};
return t;
