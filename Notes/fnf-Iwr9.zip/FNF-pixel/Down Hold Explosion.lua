local sButton = Var'Button'
local t = Def.Sprite {
	Name="Glow";
	Texture=NOTESKIN:GetPath( '_'..sButton, 'glow' );
	Frames=Sprite.LinearFrames(2, 0.1);
	InitCommand=function(self)
		self:diffusealpha(0)
	end;
	W1Command=function(self)
		self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
	end;
	W2Command=function(self)
		self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
	end;
	W3Command=function(self)
		self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
	end;
	HoldingOnCommand=function(self)
		self:diffusealpha(1):setstate(0)
	end;
	HoldingOffCommand=function(self)
		self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
	end;
	RollOnCommand=function(self)
		self:diffusealpha(1):setstate(0)
	end;
	RollOffCommand=function(self)
		self:stoptweening():diffusealpha(1):setstate(0):sleep(0.0999):diffusealpha(0)
	end;
}
return t;