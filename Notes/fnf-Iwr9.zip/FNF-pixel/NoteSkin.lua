local ret = ... or {};
local var = Var;
ret.RedirTable =
{
	Up = "Up",
	Down = "Down",
	Left = "Left",
	Right = "Right",
	UpLeft = "Up",
	UpRight = "Up",

	key1 = "Left",
	Key2 = "Up",
	Key3 = "Left",
	Key4 = "Down",
	Key5 = "Right",
	Key6 = "Up",
	Key7 = "Right",
};
local OldRedir = ret.Redir;
ret.Redir = function(sButton, sElement)
	sButton, sElement = OldRedir(sButton, sElement);
	--switch element
	if  string.find(Var"Element","Head") or sElement == "Tap Fake" then
		sElement = "Tap Note"
	end
	if  string.find(Var"Element","Hold Body") then
		sElement = "Hold Body"
	end
	if  string.find(Var"Element","Roll Body") then
		sElement = "Roll Body"
	end
	if  string.find(Var"Element","Bottomcap") then
		sElement = "Tail"
	end
	--switch button
	sButton = ret.RedirTable[sButton];
	if sElement == "Receptor" or sElement == "Hold Explosion" then
		sButton = "Down"
	end
	if GAMESTATE:GetCurrentStyle():GetStepsType() == "StepsType_Dance_Solo" then
		if Var'Button' == "Up" then
			sButton = "Right"
		elseif Var'Button' == "Down" then
			sButton = "Left"
		end
	end
	return sButton, sElement;
end

local OldFunc = ret.Load;
function ret.Load()
	local t = OldFunc();
	local sElement = Var "Element";
	local sButton = Var "Button";
	if Var "Element" == "Tap Mine" then
		t.BaseRotationZ =nil;
	end
	return t;
end
ret.PartsToRotate =
{
	["Receptor"] = true,
	["Tap Note"] = true,
	["Tap Fake"] = true,
	["Tap Lift"] = true,
	["Tap Addition"] = true,
	["Hold Explosion"] = true,
	["Hold Head Active"] = true,
	["Hold Head Inactive"] = true,
	["Roll Explosion"] = true,
	["Roll Head Active"] = true,
	["Roll Head Inactive"] = true,
};
ret.Rotate =
{
	Up = 180,
	Down = 0,
	Left = 90,
	Right = -90,
	UpLeft = 0,
	UpRight = 90,
	Key1 = 0,
	Key2 = 90,
	Key3 = -90,
	Key4 = 0,
	Key5 = 180,
	Key6 = -90,
	Key7 = 90,
};
ret.Blank =
{
	["Tap Lift"] = true,
	["Tap Explosion Dim"] = true,
	["Tap Explosion Bright"] = true,
	["Roll Explosion"] = true,
	["Hold Head Active"] = true,
	["Hold Topcap Active"] = true,
	["Hold Topcap Inactive"] = true,
	["Roll Topcap Active"] = true,
	["Roll Topcap Inactive"] = true,
	["Hold Tail Active"] = true,
	["Hold Tail Inactive"] = true,
	["Roll Tail Active"] = true,
	["Roll Tail Inactive"] = true,
	["Tap Sparkle"] = true,
	["Ovceptor"] = true,
};
return ret;
