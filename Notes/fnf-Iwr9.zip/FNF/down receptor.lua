local sButton = Var'Button'
local st = GAMESTATE:GetCurrentStyle():GetStepsType() 
local cntrl = Var("Controller")
local t = Def.ActorFrame {
	ExplosionHoldingOnMessageCommand=function(self,params)
		if params.key == sButton and params.cntrl == cntrl then
			self:queuecommand("HoldingAction")
		end
	end;
	HoldingActionCommand=function(self)
		self:sleep(0.12):queuecommand("HoldingAction")
	end;
	ExplosionHoldingOffMessageCommand=function(self,params)
		if params.key == sButton and params.cntrl == cntrl then
			self:stoptweening()
		end
	end;
}
t[#t+1] = Def.ActorFrame {
	Name="Receptor",
	NoneCommand=function(self)
		self:stoptweening():zoom(0.85):linear(0.12):zoom(1)
	end;
	HoldingActionCommand=function(self)
		self:stoptweening():zoom(1.08):decelerate(0.3):zoom(1)
	end;
	W1Command=function(self)
		self:stoptweening():zoom(1.08):decelerate(0.3):zoom(1)
	end;
	W2Command=function(self)
		self:stoptweening():zoom(1.08):decelerate(0.3):zoom(1)
	end;
	W3Command=function(self)
		self:stoptweening():zoom(1.08):decelerate(0.3):zoom(1)
	end;
	W4Command=function(self)
		self:stoptweening():zoom(1.08):decelerate(0.3):zoom(1)
	end;
	W5Command=function(self)
		self:stoptweening():zoom(1.08):decelerate(0.3):zoom(1)
	end;
	MissCommand=function(self)
		self:stoptweening():zoom(1.08):decelerate(0.3):zoom(1)
	end;
	Def.Sprite {
		Name="Base";
		Texture=NOTESKIN:GetPath( '', '_Receptor' );
	};
	Def.Sprite {
		Name="Glow";
		Texture=NOTESKIN:GetPath( sButton, 'tap note' );
		InitCommand=function(self)
			self:diffusealpha(0)
		end;
		NoneCommand=function(self)
			self:stoptweening():diffusealpha(0.3)
		end;
		LiftCommand=function(self)
			self:linear(0.12):diffusealpha(0)
		end;
	};
};






return t;
