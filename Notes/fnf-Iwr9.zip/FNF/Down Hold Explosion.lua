local sButton = Var'Button'
local cntrl = Var("Controller")
local t = Def.ActorFrame {
	HoldingOnCommand=function(self)
		MESSAGEMAN:Broadcast("ExplosionHoldingOn",{key=sButton,cntrl=cntrl})
		self:queuecommand("HoldingAction")
	end	,
	HoldingOffCommand=function(self)
		MESSAGEMAN:Broadcast("ExplosionHoldingOff",{key=sButton,cntrl=cntrl})
		self:stoptweening()
	end	,
	RollOnCommand=function(self)
		MESSAGEMAN:Broadcast("ExplosionHoldingOn",{key=sButton,cntrl=cntrl})
		self:queuecommand("HoldingAction")
	end	,
	RollOffCommand=function(self)
		MESSAGEMAN:Broadcast("ExplosionHoldingOff",{key=sButton,cntrl=cntrl})
		self:stoptweening()
	end	,
	HoldingActionCommand=function(self)
		self:sleep(0.12):queuecommand("HoldingAction")		
	end	,
	Def.ActorFrame {
		InitCommand=function(self)
			self:GetChild("Glow"):blend(1)
			self:diffusealpha(0)
		end;
		W1Command=function(self)
			self:stoptweening():zoom(1.08):diffusealpha(2):decelerate(0.3):diffusealpha(0):zoom(1)
		end;
		W2Command=function(self)
			self:stoptweening():zoom(1.08):diffusealpha(2):decelerate(0.3):diffusealpha(0):zoom(1)
		end;
		W3Command=function(self)
			self:stoptweening():zoom(1.08):diffusealpha(2):decelerate(0.3):diffusealpha(0):zoom(1)
		end;
		HoldingActionCommand=function(self)
			self:stoptweening():zoom(1.08):diffusealpha(2):decelerate(0.3):diffusealpha(0):zoom(1)
		end;
		Def.Sprite {
			Texture=NOTESKIN:GetPath( '', '_glow base' );
		};
		Def.Sprite {
			Name="Glow";
			Texture=NOTESKIN:GetPath( '_'..sButton, 'glow' );
		};
	};

}
return t;