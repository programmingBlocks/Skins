Wafles 3 Noteskin for Stepmania 5

Shapes based off of delta noteskin by Shakesoda.
Completely made from scratch by Wafles.